import { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Sparkles, Send, Star, Clock } from "lucide-react";
import { AI_REPLIES, QUICK_PROMPTS } from "./aiData";
import type { ChatMsg, AiMovie, AiShowtime } from "./types";

// ─── LOCAL HELPERS ─────────────────────────────────────────────────────────────

function StarRating({ r }: { r: number }) {
  return (
    <span className="flex items-center gap-1">
      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
      <span className="text-amber-400 text-xs font-semibold">{r.toFixed(1)}</span>
    </span>
  );
}

function formatDuration(m: number) {
  return `${Math.floor(m / 60)}g ${m % 60}p`;
}

function getTime() {
  return new Date().toLocaleTimeString("vi", { hour: "2-digit", minute: "2-digit" });
}

// ─── MOVIE RECOMMENDATION CARD ────────────────────────────────────────────────

function MovieRecommendationCard({
  movie,
  showtimes,
  onSelect,
}: {
  movie: AiMovie;
  showtimes: AiShowtime[];
  onSelect: (m: AiMovie) => void;
}) {
  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden w-full">
      <div className="flex gap-3 p-3">
        <img
          src={movie.poster}
          alt={movie.title}
          className="w-14 h-20 object-cover rounded-xl flex-none bg-zinc-900"
        />
        <div className="flex-1 min-w-0">
          <h4
            className="text-foreground font-bold text-xs leading-snug line-clamp-2 mb-1"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {movie.title}
          </h4>
          <div className="flex items-center gap-2 mb-2">
            <StarRating r={movie.rating} />
            <span className="text-muted-foreground text-[10px] flex items-center gap-1">
              <Clock className="w-2.5 h-2.5" /> {formatDuration(movie.duration)}
            </span>
          </div>
          <div className="bg-primary/10 border border-primary/15 rounded-lg p-2 mb-2">
            <p className="text-primary text-[10px] leading-snug">
              🎯 Phù hợp với sở thích {movie.genre[0].toLowerCase()} của bạn
            </p>
          </div>
          <button
            onClick={() => onSelect(movie)}
            className="w-full bg-primary text-black text-[11px] font-bold py-1.5 rounded-xl active:scale-95 transition-all"
          >
            Đặt vé ngay
          </button>
        </div>
      </div>

      {/* Quick showtime chips */}
      <div className="px-3 pb-3 flex gap-2 overflow-x-auto scrollbar-hide">
        {showtimes.slice(0, 3).map(s => (
          <button
            key={s.id}
            onClick={() => onSelect(movie)}
            className="flex-none bg-secondary border border-border text-[10px] font-semibold text-foreground px-2.5 py-1.5 rounded-lg whitespace-nowrap hover:border-primary/40 transition-colors"
          >
            {s.time} · CGV Q.1
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── TYPING INDICATOR ─────────────────────────────────────────────────────────

function TypingIndicator() {
  return (
    <div className="flex gap-2 justify-start">
      <div className="w-7 h-7 rounded-full bg-primary/15 border border-primary/25 flex items-center justify-center flex-none self-end">
        <Sparkles className="w-3 h-3 text-primary" />
      </div>
      <div className="bg-secondary border border-border rounded-2xl rounded-bl-sm px-4 py-3">
        <div className="flex gap-1.5 items-center">
          {[0, 1, 2].map(i => (
            <motion.div
              key={i}
              className="w-2 h-2 rounded-full bg-primary/50"
              animate={{ scale: [1, 1.5, 1], opacity: [0.3, 1, 0.3] }}
              transition={{ repeat: Infinity, duration: 1, delay: i * 0.22 }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── MESSAGE BUBBLE ───────────────────────────────────────────────────────────

function MessageBubble({
  msg,
  showtimes,
  onMovieSelect,
}: {
  msg: ChatMsg;
  showtimes: AiShowtime[];
  onMovieSelect: (m: AiMovie) => void;
}) {
  const isUser = msg.role === "user";
  return (
    <div className={`flex gap-2 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className="w-7 h-7 rounded-full bg-primary/15 border border-primary/25 flex items-center justify-center flex-none self-end">
          <Sparkles className="w-3 h-3 text-primary" />
        </div>
      )}
      <div className={`max-w-[82%] flex flex-col gap-2 ${isUser ? "items-end" : "items-start"}`}>
        <div
          className={`rounded-2xl px-4 py-3 ${
            isUser
              ? "bg-primary text-black rounded-br-sm"
              : "bg-secondary border border-border rounded-bl-sm"
          }`}
        >
          <p className={`text-sm leading-relaxed ${isUser ? "text-black" : "text-foreground"}`}>
            {msg.text}
          </p>
        </div>

        {msg.recs?.map(mv => (
          <MovieRecommendationCard
            key={mv.id}
            movie={mv}
            showtimes={showtimes}
            onSelect={onMovieSelect}
          />
        ))}

        <span className="text-muted-foreground text-[10px]">{msg.time}</span>
      </div>
    </div>
  );
}

// ─── AI CHAT SCREEN ───────────────────────────────────────────────────────────

interface AiChatScreenProps {
  movies: AiMovie[];
  showtimes: AiShowtime[];
  onMovieSelect: (m: AiMovie) => void;
}

export function AiChatScreen({ movies, showtimes, onMovieSelect }: AiChatScreenProps) {
  const [msgs, setMsgs] = useState<ChatMsg[]>([
    {
      id: "0",
      role: "ai",
      text: "Xin chào! Tôi là CineAI 🎬 Trợ lý điện ảnh thông minh. Hãy cho tôi biết bạn muốn xem thể loại nào, hoặc tâm trạng hôm nay — tôi sẽ gợi ý phim hoàn hảo nhất!",
      time: "09:00",
    },
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);

  const send = () => {
    if (!input.trim() || thinking) return;
    const userMsg: ChatMsg = { id: Date.now().toString(), role: "user", text: input, time: getTime() };
    setMsgs(prev => [...prev, userMsg]);
    setInput("");
    setThinking(true);
    setTimeout(() => {
      const reply = AI_REPLIES[Math.floor(Math.random() * AI_REPLIES.length)];
      const recs = reply.ids.map(id => movies.find(m => m.id === id)).filter(Boolean) as AiMovie[];
      setMsgs(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: "ai", text: reply.text, recs, time: getTime() },
      ]);
      setThinking(false);
    }, 1400 + Math.random() * 600);
  };

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs, thinking]);

  return (
    <div className="flex-1 flex flex-col bg-background overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-5 pt-12 pb-4 border-b border-border flex-none">
        <div className="w-10 h-10 rounded-full bg-primary/15 border border-primary/25 flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="text-foreground font-bold text-base">CineAI Trợ lý</h2>
          <p className="flex items-center gap-1 text-xs text-green-400">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block" />
            Đang hoạt động
          </p>
        </div>
      </div>

      {/* Message list */}
      <div ref={listRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-4 scrollbar-hide">
        {msgs.map(m => (
          <MessageBubble
            key={m.id}
            msg={m}
            showtimes={showtimes}
            onMovieSelect={onMovieSelect}
          />
        ))}
        {thinking && <TypingIndicator />}
      </div>

      {/* Input area */}
      <div className="flex-none border-t border-border bg-card px-4 pt-3 pb-4">
        <div className="flex gap-2 overflow-x-auto scrollbar-hide mb-3">
          {QUICK_PROMPTS.map(p => (
            <button
              key={p}
              onClick={() => setInput(p)}
              className="flex-none bg-secondary border border-border text-muted-foreground text-[11px] px-3 py-1.5 rounded-full whitespace-nowrap hover:border-primary/40 hover:text-foreground transition-colors"
            >
              {p}
            </button>
          ))}
        </div>
        <div className="flex items-end gap-2">
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder="Nhập tin nhắn..."
            rows={1}
            className="flex-1 bg-secondary border border-border rounded-2xl px-4 py-2.5 text-foreground text-sm outline-none focus:border-primary/50 transition-colors resize-none placeholder:text-muted-foreground"
            style={{ minHeight: 42, maxHeight: 112 }}
          />
          <button
            onClick={send}
            disabled={!input.trim() || thinking}
            className="w-11 h-11 rounded-full bg-primary flex items-center justify-center flex-none disabled:opacity-30 hover:bg-primary/90 active:scale-90 transition-all"
          >
            <Send className="w-4 h-4 text-black" />
          </button>
        </div>
      </div>
    </div>
  );
}
