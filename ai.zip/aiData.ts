export const AI_REPLIES = [
  {
    text: "Tuyệt! Dựa trên sở thích hành động và Sci-Fi của bạn, tôi gợi ý những bộ phim đỉnh cao này 🎬",
    ids: ["m1", "m4"],
  },
  {
    text: "Bạn muốn phim ngắn hơn 2 tiếng? Đây là lựa chọn hoàn hảo không kém phần hấp dẫn:",
    ids: ["m4"],
  },
  {
    text: "Cuối tuần muốn thư giãn? Tôi có gợi ý lãng mạn nhẹ nhàng hoặc bom tấn mới nhất:",
    ids: ["m5", "m6"],
  },
  {
    text: "Phim bom tấn 2026 được yêu thích nhất hiện tại. Tôi nghĩ bạn sẽ ấn tượng với:",
    ids: ["m2", "m3"],
  },
];

export const QUICK_PROMPTS = [
  "Phim hot nhất",
  "Phim < 2 tiếng",
  "Phim lãng mạn",
  "Bom tấn hành động",
];
