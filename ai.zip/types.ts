export interface ChatMsg {
  id: string;
  role: "user" | "ai";
  text: string;
  recs?: AiMovie[];
  time: string;
}

// Subset of Movie fields used by the chatbot
export interface AiMovie {
  id: string;
  title: string;
  poster: string;
  genre: string[];
  duration: number;
  rating: number;
}

export interface AiShowtime {
  id: string;
  time: string;
}
